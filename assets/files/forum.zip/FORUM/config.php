<?php
session_start();

define('DB_HOST', 'localhost');
define('DB_NAME', 'u482683110_26LALIE_BDD');
define('DB_USER', 'u482683110_26LALIE');
define('DB_PASS', 'I6lal30?');

try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    error_log("Erreur de connexion : " . $e->getMessage());
    die("Erreur de connexion à la base de données. Veuillez réessayer plus tard.");
}

function est_connecte() { return isset($_SESSION['user_id']); }
function est_admin() { return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1; }

function logger($action, $details = null, $user_id = null) {
    global $pdo;
    if ($user_id === null && isset($_SESSION['user_id'])) $user_id = $_SESSION['user_id'];
    $sql = "INSERT INTO forum_logs (user_id, action, details, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id, $action, $details, $_SERVER['REMOTE_ADDR'] ?? 'inconnue', $_SERVER['HTTP_USER_AGENT'] ?? 'inconnu']);
}

function creer_notification($user_id, $titre, $contenu, $lien = null) {
    global $pdo;
    $sql = "INSERT INTO forum_notifications (user_id, titre, contenu, lien) VALUES (?, ?, ?, ?)";
    return $pdo->prepare($sql)->execute([$user_id, $titre, $contenu, $lien]);
}

function get_notifications($user_id, $pdo, $non_lues_seulement = true) {
    $sql = "SELECT * FROM forum_notifications WHERE user_id = ?";
    if ($non_lues_seulement) $sql .= " AND is_read = 0";
    $sql .= " ORDER BY created_at DESC LIMIT 10";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

function valider_entree($data, $type = 'texte') {
    $data = trim($data);
    $data = htmlspecialchars($data);
    if ($type === 'email' && !filter_var($data, FILTER_VALIDATE_EMAIL)) return false;
    if ($type === 'int') $data = filter_var($data, FILTER_VALIDATE_INT);
    if ($type === 'url') $data = filter_var($data, FILTER_VALIDATE_URL);
    return $data;
}

function gerer_exception($e) {
    error_log("Erreur: " . $e->getMessage() . " dans " . $e->getFile() . " ligne " . $e->getLine());
    return (est_connecte() && est_admin()) ? "Erreur: " . $e->getMessage() : "Une erreur s'est produite. Notre équipe a été notifiée.";
}

function get_pagination($page_actuelle, $total_elements, $elements_par_page = 10) {
    $total_pages = ceil($total_elements / $elements_par_page);
    $page_actuelle = max(1, min($page_actuelle, $total_pages));
    return [
        'page_actuelle' => $page_actuelle,
        'total_pages' => $total_pages,
        'offset' => ($page_actuelle - 1) * $elements_par_page,
        'elements_par_page' => $elements_par_page
    ];
}
?>
