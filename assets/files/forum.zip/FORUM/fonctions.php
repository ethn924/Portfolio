<?php
function afficher_erreur($message) { return "<div class='erreur'>$message</div>"; }
function afficher_succes($message) { return "<div class='succes'>$message</div>"; }
function afficher_info($message) { return "<div class='info'>$message</div>"; }

function get_question_plus_reponses($pdo) {
    return $pdo->query("SELECT q.q_id, q.q_titre, COUNT(r.r_id) as nb_reponses FROM forum_question q LEFT JOIN forum_reponse r ON q.q_id = r.r_fk_question_id GROUP BY q.q_id ORDER BY nb_reponses DESC LIMIT 1")->fetch();
}

function get_questions_populaires($pdo) {
    return $pdo->query("SELECT q.q_titre, COUNT(r.r_id) as nb_reponses FROM forum_question q LEFT JOIN forum_reponse r ON q.q_id = r.r_fk_question_id GROUP BY q.q_id ORDER BY nb_reponses DESC LIMIT 5")->fetchAll();
}

function get_nombre_total_questions($pdo) {
    return $pdo->query("SELECT COUNT(*) as total FROM forum_question")->fetch()['total'];
}

function get_nombre_total_reponses($pdo) {
    return $pdo->query("SELECT COUNT(*) as total FROM forum_reponse")->fetch()['total'];
}

function formater_date_fr($date_sql) {
    if (!$date_sql) return 'Non spécifiée';
    $timestamp = strtotime($date_sql);
    $jours = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
    $mois = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
    return $jours[date('w', $timestamp)] . " " . date('j', $timestamp) . " " . $mois[date('n', $timestamp) - 1] . " " . date('Y H:i', $timestamp);
}

function formater_date_relative($date_sql) {
    $maintenant = new DateTime();
    $date = new DateTime($date_sql);
    $interval = $maintenant->diff($date);
    if ($interval->y > 0) return "il y a {$interval->y} an" . ($interval->y > 1 ? 's' : '');
    if ($interval->m > 0) return "il y a {$interval->m} mois";
    if ($interval->d > 0) return "il y a {$interval->d} jour" . ($interval->d > 1 ? 's' : '');
    if ($interval->h > 0) return "il y a {$interval->h} heure" . ($interval->h > 1 ? 's' : '');
    if ($interval->i > 0) return "il y a {$interval->i} minute" . ($interval->i > 1 ? 's' : '');
    return "à l'instant";
}

function get_likes_count($pdo, $r_id) {
    return $pdo->prepare("SELECT COUNT(*) as count FROM forum_likes WHERE r_id = ?")->execute([$r_id]) ? $pdo->prepare("SELECT COUNT(*) as count FROM forum_likes WHERE r_id = ?")->fetch()['count'] : 0;
}

function user_has_liked($pdo, $user_id, $r_id) {
    if (!$user_id) return false;
    $stmt = $pdo->prepare("SELECT like_id FROM forum_likes WHERE user_id = ? AND r_id = ?");
    $stmt->execute([$user_id, $r_id]);
    return $stmt->fetch() ? true : false;
}

function get_commentaires($pdo, $r_id) {
    $stmt = $pdo->prepare("SELECT c.*, u.login, u.avatar, u.reputation FROM forum_commentaires c JOIN forum_utilisateur u ON c.user_id = u.user_id WHERE c.r_id = ? ORDER BY c.created_at ASC");
    $stmt->execute([$r_id]);
    return $stmt->fetchAll();
}

function rechercher($pdo, $terme, $page = 1, $par_page = 10) {
    $terme = "%$terme%";
    $sql_count = "SELECT COUNT(DISTINCT q.q_id) as total FROM forum_question q LEFT JOIN forum_reponse r ON q.q_id = r.r_fk_question_id WHERE q.q_titre LIKE ? OR q.q_contenu LIKE ? OR r.r_contenu LIKE ?";
    $stmt = $pdo->prepare($sql_count);
    $stmt->execute([$terme, $terme, $terme]);
    $total = $stmt->fetch()['total'];
    $pagination = get_pagination($page, $total, $par_page);
    
    $sql = "SELECT q.*, u.login, (SELECT COUNT(*) FROM forum_reponse r2 WHERE r2.r_fk_question_id = q.q_id) as nb_reponses FROM forum_question q LEFT JOIN forum_utilisateur u ON q.user_id = u.user_id WHERE q.q_titre LIKE ? OR q.q_contenu LIKE ? OR q.q_id IN (SELECT DISTINCT r.r_fk_question_id FROM forum_reponse r WHERE r.r_contenu LIKE ?) GROUP BY q.q_id ORDER BY q.last_activity DESC LIMIT " . (int)$par_page . " OFFSET " . (int)$pagination['offset'];
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$terme, $terme, $terme]);
    return ['resultats' => $stmt->fetchAll(), 'pagination' => $pagination, 'total' => $total];
}

function generer_slug($texte) {
    $texte = preg_replace('~[^\pL\d]+~u', '-', $texte);
    $texte = iconv('utf-8', 'us-ascii//TRANSLIT', $texte);
    $texte = preg_replace('~[^-\w]+~', '', $texte);
    $texte = trim($texte, '-');
    $texte = preg_replace('~-+~', '-', $texte);
    return strtolower($texte) ?: 'question';
}

function marquer_comme_solution($pdo, $r_id, $user_id) {
    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("SELECT r_fk_question_id, user_id FROM forum_reponse WHERE r_id = ?");
        $stmt->execute([$r_id]);
        $reponse = $stmt->fetch();
        if (!$reponse) throw new Exception("Réponse non trouvée");
        
        $stmt = $pdo->prepare("SELECT user_id FROM forum_question WHERE q_id = ?");
        $stmt->execute([$reponse['r_fk_question_id']]);
        $question = $stmt->fetch();
        if ($question['user_id'] != $user_id && !est_admin()) throw new Exception("Vous n'êtes pas autorisé à marquer cette réponse comme solution");
        
        $pdo->prepare("UPDATE forum_reponse SET is_solution = 0 WHERE r_fk_question_id = ?")->execute([$reponse['r_fk_question_id']]);
        $pdo->prepare("UPDATE forum_reponse SET is_solution = 1 WHERE r_id = ?")->execute([$r_id]);
        $pdo->prepare("UPDATE forum_utilisateur SET reputation = reputation + 15 WHERE user_id = ?")->execute([$reponse['user_id']]);
        $pdo->commit();
        creer_notification($reponse['user_id'], 'Votre réponse a été marquée comme solution', 'Félicitations ! Votre réponse a été sélectionnée comme solution et vous gagnez 15 points de réputation.', "question.php?id={$reponse['r_fk_question_id']}");
        return true;
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

function est_en_favoris($pdo, $user_id, $question_id) {
    if (!$user_id) return false;
    $stmt = $pdo->prepare("SELECT id FROM forum_favoris WHERE user_id = ? AND question_id = ?");
    $stmt->execute([$user_id, $question_id]);
    return $stmt->fetch() ? true : false;
}

function afficher_header($titre = 'Forum de discussion', $pdo = null) {
    global $pdo;
    $notifications = [];
    if (est_connecte()) {
        $notifications = get_notifications($_SESSION['user_id'], $pdo, true);
    }
    ?>
    <header>
        <div class="header-container">
            <div class="header-brand">
                <h1><a href="index.php"><?= htmlspecialchars($titre) ?></a></h1>
            </div>
            <nav class="header-nav">
                <a href="index.php" class="nav-link">Accueil</a>
                <a href="recherche.php" class="nav-link">Rechercher</a>
                <?php if (est_connecte()): ?>
                    <a href="ajouter_question.php" class="nav-link">Poser une question</a>
                    <a href="mes_favoris.php" class="nav-link">Favoris</a>
                    <div class="nav-user">
                        <a href="profil.php" class="nav-link user-link"><span><?= htmlspecialchars($_SESSION['login']) ?></span></a>
                        <?php if (est_admin()): ?>
                            <a href="admin.php" class="nav-link admin-link" title="Administration">Admin</a>
                        <?php endif; ?>
                        <a href="deconnexion.php" class="nav-link logout-link">Déconnexion</a>
                    </div>
                <?php else: ?>
                    <div class="nav-auth">
                        <a href="connexion.php" class="nav-link">Connexion</a>
                        <a href="inscription.php" class="nav-link btn-signup">S'inscrire</a>
                    </div>
                <?php endif; ?>
            </nav>
            <?php if (!empty($notifications)): ?>
                <div class="header-notifications">
                    <button class="notif-btn" title="Notifications">
                        <span class="notif-count"><?= count($notifications) ?></span>
                    </button>
                    <div class="notif-dropdown">
                        <?php foreach($notifications as $notif): ?>
                            <a href="<?= htmlspecialchars($notif['lien'] ?? '#') ?>" class="notif-item">
                                <strong><?= htmlspecialchars($notif['titre']) ?></strong>
                                <p><?= htmlspecialchars($notif['contenu']) ?></p>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </header>
    <?php
}
?>
