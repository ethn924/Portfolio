<?php
require_once 'config.php';
require_once 'fonctions.php'; // Ajout de cette ligne

$erreur = '';
$succes = '';

if ($_POST) {
    $login = $_POST['login'] ?? '';
    $mdp = $_POST['mdp'] ?? '';
    
    if ($login && $mdp) {
        // Récupérer l'utilisateur par login
        $sql = "SELECT * FROM forum_utilisateur WHERE login = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$login]);
        $user = $stmt->fetch();
        
        // Vérifier le mot de passe
        if ($user && password_verify($mdp, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['login'] = $user['login'];
            $_SESSION['is_admin'] = $user['is_admin'];
            
            // Mettre à jour la dernière connexion
            $sql = "UPDATE forum_utilisateur SET derniere_connexion = NOW() WHERE user_id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$user['user_id']]);
            
            $_SESSION['connexion_succes'] = "Bienvenue $login ! Vous êtes connecté.";
            
            header('Location: index.php');
            exit;
        } else {
            $erreur = "Identifiants incorrects";
        }
    } else {
        $erreur = "Veuillez remplir tous les champs";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Connexion</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="connexion.css">
</head>
<body>
    <?php afficher_header('Connexion'); ?>

    <main style="max-width: 100%; padding: 0; margin: 0; display: flex; align-items: stretch; min-height: calc(100vh - 70px);">
        <div style="flex: 1; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; padding: 40px; min-height: 100%;">
            <div style="color: white; text-align: center;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 80px; height: 80px; margin: 0 auto 20px; animation: iconFloat 3s ease-in-out infinite;">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                </svg>
                <h2 style="font-size: 32px; margin-bottom: 15px; font-weight: 800;">Connexion</h2>
                <p style="font-size: 16px; opacity: 0.9;">Accédez à votre compte pour participer au forum</p>
            </div>
        </div>
        
        <div style="flex: 1; display: flex; align-items: center; justify-content: center; padding: 40px; background: #f9fafb;">
            <div style="width: 100%; max-width: 400px;">
                <?php if ($erreur): ?>
                    <?= afficher_erreur($erreur) ?>
                <?php endif; ?>
                
                <form method="post">
                    <div class="form-group">
                        <label>Login :</label>
                        <input type="text" name="login" required autofocus>
                    </div>
                    <div class="form-group">
                        <label>Mot de passe :</label>
                        <input type="password" name="mdp" required>
                    </div>
                    <button type="submit" class="submit-button">Se connecter</button>
                </form>
                
                <div class="auth-links">
                    <p>Pas encore de compte ? <a href="inscription.php">S'inscrire</a></p>
                    <a href="index.php" class="back-link">← Retour à l'accueil</a>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <p>Forum de discussion © 2025 - <?= date('Y') ?></p>
    </footer>
</body>
</html>