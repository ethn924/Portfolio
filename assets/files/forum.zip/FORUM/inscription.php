<?php
require_once 'config.php';
require_once 'fonctions.php'; // Ajout de cette ligne

$erreur = '';
$succes = '';

if ($_POST) {
    $login = valider_entree($_POST['login'] ?? '');
    $mdp = $_POST['mdp'] ?? '';
    $confirmation = $_POST['confirmation'] ?? '';
    
    if ($login && $mdp && $confirmation) {
        if (strlen($mdp) < 6) {
            $erreur = "Le mot de passe doit contenir au moins 6 caractères";
        } elseif ($mdp !== $confirmation) {
            $erreur = "Les mots de passe ne correspondent pas";
        } elseif (strlen($login) < 3) {
            $erreur = "Le login doit contenir au moins 3 caractères";
        } else {
            // Vérifier si le login existe déjà
            $sql = "SELECT user_id FROM forum_utilisateur WHERE login = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$login]);
            
            if ($stmt->fetch()) {
                $erreur = "Ce login est déjà utilisé";
            } else {
                // Créer le nouvel utilisateur avec password hashé
                $mdp_hash = password_hash($mdp, PASSWORD_DEFAULT);
                $sql = "INSERT INTO forum_utilisateur (login, password) VALUES (?, ?)";
                $stmt = $pdo->prepare($sql);
                
                if ($stmt->execute([$login, $mdp_hash])) {
                    $succes = "Inscription réussie ! Vous pouvez maintenant vous connecter.";
                } else {
                    $erreur = "Erreur lors de l'inscription";
                }
            }
        }
    } else {
        $erreur = "Veuillez remplir tous les champs";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Inscription</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="connexion.css">
</head>
<body>
    <?php afficher_header('Inscription'); ?>

    <main style="max-width: 100%; padding: 0; margin: 0; display: flex; align-items: stretch; min-height: calc(100vh - 70px);">
        <div style="flex: 1; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; padding: 40px; min-height: 100%;">
            <div style="color: white; text-align: center;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 80px; height: 80px; margin: 0 auto 20px; animation: iconFloat 3s ease-in-out infinite;">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                </svg>
                <h2 style="font-size: 32px; margin-bottom: 15px; font-weight: 800;">Rejoignez-nous</h2>
                <p style="font-size: 16px; opacity: 0.9;">Créez un compte pour participer au forum</p>
            </div>
        </div>
        
        <div style="flex: 1; display: flex; align-items: center; justify-content: center; padding: 40px; background: #f9fafb;">
            <div style="width: 100%; max-width: 400px;">
                <?php if ($erreur): ?>
                    <?= afficher_erreur($erreur) ?>
                <?php endif; ?>
                
                <?php if ($succes): ?>
                    <?= afficher_succes($succes) ?>
                    <div class="auth-links">
                        <a href="connexion.php">Se connecter</a>
                    </div>
                <?php else: ?>
                    <form method="post">
                        <div class="form-group">
                            <label>Login :</label>
                            <input type="text" name="login" required autofocus>
                        </div>
                        <div class="form-group">
                            <label>Mot de passe :</label>
                            <input type="password" name="mdp" required>
                        </div>
                        <div class="form-group">
                            <label>Confirmation du mot de passe :</label>
                            <input type="password" name="confirmation" required>
                        </div>
                        <button type="submit" class="submit-button">S'inscrire</button>
                    </form>
                    
                    <div class="auth-links">
                        <p>Déjà un compte ? <a href="connexion.php">Se connecter</a></p>
                    </div>
                <?php endif; ?>
                
                <div style="text-align: center; margin-top: 20px;">
                    <a href="index.php" class="back-link">← Retour à l'accueil</a>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <p>Forum de discussion © 2025 - <?= date('Y') ?></p>
    </footer>
</body>
</html>