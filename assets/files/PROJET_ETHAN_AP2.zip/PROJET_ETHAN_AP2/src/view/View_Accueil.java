package view;

import java.sql.SQLException;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class View_Accueil {

    private JFrame frame;

    public View_Accueil() throws ClassNotFoundException, SQLException {
        initialize();
        frame.setVisible(true);
    }

    private void initialize() {
        frame = new JFrame();
        frame.setTitle("Bibliothèque");
        frame.setBounds(100, 100, 400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel titreLabel = new JLabel("BIBLIOTHEQUE");
        titreLabel.setBounds(100, 20, 200, 30);
        titreLabel.setHorizontalAlignment(SwingConstants.CENTER);
        frame.getContentPane().add(titreLabel);

        JButton btnLivres = new JButton("Voir tous les livres");
        btnLivres.setBounds(50, 70, 300, 40);
        frame.getContentPane().add(btnLivres);

        JButton btnEmprunter = new JButton("Emprunter un livre");
        btnEmprunter.setBounds(50, 120, 300, 40);
        frame.getContentPane().add(btnEmprunter);

        JButton btnCompte = new JButton("Voir mon compte");
        btnCompte.setBounds(50, 170, 300, 40);
        frame.getContentPane().add(btnCompte);

        JButton btnDeconnexion = new JButton("Déconnexion");
        btnDeconnexion.setBounds(50, 220, 300, 30);
        frame.getContentPane().add(btnDeconnexion);

        btnLivres.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new View_Catalogue();
            }
        });

        btnEmprunter.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new View_Emprunt();
            }
        });

        btnCompte.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new View_Compte(controller.mainMVC.getM().getAdherentConnecte());
            }
        });

        btnDeconnexion.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controller.mainMVC.getM().setAdherentConnecte(null);
                frame.dispose();
                new View_Connexion();
            }
        });
    }
}