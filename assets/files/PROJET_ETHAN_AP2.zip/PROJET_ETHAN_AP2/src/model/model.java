package model;

import java.sql.*;
import java.util.ArrayList;

public class model {
	private static final String url = "jdbc:mysql://localhost:3306/ap2_ethan_2025";
	private static final String user = "root";
	private static final String passwd = "root";

	private ArrayList<LIVRE> ListLivre;
	private ArrayList<AUTEUR> ListAuteur;
	private ArrayList<ADHERENT> ListAdherent;
	private ADHERENT adherentConnecte;

	public void getAll() throws SQLException, ClassNotFoundException {
		ListAdherent = new ArrayList<ADHERENT>();
		ListAuteur = new ArrayList<AUTEUR>();
		ListLivre = new ArrayList<LIVRE>();

		Connection conn = DriverManager.getConnection(url, user, passwd);
		Statement stmt = conn.createStatement();

		ResultSet auteurToList = stmt.executeQuery("SELECT * FROM auteur");
		while (auteurToList.next()) {
			String num = auteurToList.getString("num");
			String nom = auteurToList.getString("nom");
			String prenom = auteurToList.getString("prenom");
			String date_naissance = auteurToList.getString("date_naissance");
			String description = auteurToList.getString("description");
			AUTEUR auteur = new AUTEUR(num, nom, prenom, date_naissance, description);
			ListAuteur.add(auteur);
		}

		ResultSet adherentToList = stmt.executeQuery("SELECT * FROM adherent");
		while (adherentToList.next()) {
			String num = adherentToList.getString("num");
			String nom = adherentToList.getString("nom");
			String prenom = adherentToList.getString("prenom");
			String email = adherentToList.getString("email");
			ADHERENT adherent = new ADHERENT(num, nom, prenom, email, new ArrayList<LIVRE>());
			ListAdherent.add(adherent);
		}

		ResultSet livresToList = stmt.executeQuery("SELECT * FROM livre");
		while (livresToList.next()) {
			String ISBN = livresToList.getString("ISBN");
			String titre = livresToList.getString("titre");
			float prix = livresToList.getFloat("prix");
			String numAdherent = livresToList.getString("adherent");
			String numAuteur = livresToList.getString("auteur");

			LIVRE livre = new LIVRE(ISBN, titre, prix, null, null);

			if (numAuteur != null) {
				livre.setAuteur(findAuteur(numAuteur));
			}

			if (numAdherent != null) {
				ADHERENT emprunteur = findAdherent(numAdherent);
				livre.setEmprunteur(emprunteur);
				if (emprunteur != null) {
					emprunteur.getListLivre().add(livre);
				}
			}

			ListLivre.add(livre);
		}

		conn.close();
	}

	public ADHERENT findAdherent(String num) {
		for (ADHERENT a : ListAdherent) {
			if (num.equals(a.getNum())) {
				return a;
			}
		}
		return null;
	}

	public AUTEUR findAuteur(String num) {
		for (AUTEUR a : ListAuteur) {
			if (num.equals(a.getNum())) {
				return a;
			}
		}
		return null;
	}

	public LIVRE findLivre(String ISBN) {
		for (LIVRE l : ListLivre) {
			if (ISBN.equals(l.getISBN())) {
				return l;
			}
		}
		return null;
	}

	public boolean emprunterLivre(String ISBN, String numAdherent) throws SQLException {
		LIVRE livre = findLivre(ISBN);
		// Vérifier si le livre existe
		if (livre == null) {
			return false;
		}

		// Vérifier si le livre est déjà emprunté
		if (livre.getEmprunteur() != null) {
			return false;
		}

		// Vérifier si l'adhérent existe
		ADHERENT adherent = findAdherent(numAdherent);
		if (adherent == null) {
			return false;
		}

		Connection conn = DriverManager.getConnection(url, user, passwd);
		Statement stmt = conn.createStatement();
		String sql = "UPDATE livre SET adherent = '" + numAdherent + "' WHERE ISBN = '" + ISBN + "'";
		int rowsUpdated = stmt.executeUpdate(sql);
		conn.close();

		if (rowsUpdated > 0) {
			livre.setEmprunteur(adherent);
			adherent.getListLivre().add(livre);
		}

		return rowsUpdated > 0;
	}

	public boolean retournerLivre(String ISBN) throws SQLException {
		LIVRE livre = findLivre(ISBN);

		if (livre == null) {
			return false;
		}


		if (livre.getEmprunteur() == null) {
			return false;
		}

		Connection conn = DriverManager.getConnection(url, user, passwd);
		Statement stmt = conn.createStatement();
		String sql = "UPDATE livre SET adherent = NULL WHERE ISBN = '" + ISBN + "'";
		int rowsUpdated = stmt.executeUpdate(sql);
		conn.close();

		if (rowsUpdated > 0) {
			ADHERENT adherent = livre.getEmprunteur();
			if (adherent != null) {
				adherent.getListLivre().remove(livre);
			}
			livre.setEmprunteur(null);
		}

		return rowsUpdated > 0;
	}

	public boolean updateAdherent(String num, String nom, String prenom, String email) throws SQLException {
		// Vérifier si l'adhérent existe
		ADHERENT adherent = findAdherent(num);
		if (adherent == null) {
			return false;
		}

		Connection conn = DriverManager.getConnection(url, user, passwd);
		Statement stmt = conn.createStatement();
		String sql = "UPDATE adherent SET nom = '" + nom + "', prenom = '" + prenom + "', email = '" + email + "' WHERE num = '" + num + "'";
		int rowsUpdated = stmt.executeUpdate(sql);
		conn.close();

		if (rowsUpdated > 0) {
			adherent.setNom(nom);
			adherent.setPrenom(prenom);
			adherent.setEmail(email);
		}

		return rowsUpdated > 0;
	}

	public ArrayList<LIVRE> getListLivre() {
		return ListLivre;
	}

	public ArrayList<AUTEUR> getListAuteur() {
		return ListAuteur;
	}

	public ArrayList<ADHERENT> getListAdherent() {
		return ListAdherent;
	}

	public ADHERENT getAdherentConnecte() {
		return adherentConnecte;
	}

	public void setAdherentConnecte(ADHERENT adherentConnecte) {
		this.adherentConnecte = adherentConnecte;
	}
}